// Patient database
const database = [
  { 
    name: "Quinton", 
    surname: "Mthembu", 
    id: "9701226017089", 
    file: `
      <h2>Medical File: Quinton Mthembu</h2>
      <p><strong>Full Name:</strong> Quinton Mthembu</p>
      <p><strong>ID Number:</strong> 9701226017089</p>
      <p><strong>Date of Birth:</strong> 22 January 1997</p>
      <p><strong>Gender:</strong> Male</p>
      <hr>
      <h3>Medical History (June 2023 - Present)</h3>
      <table>
        <tr><th>Date</th><th>Hospital</th><th>Diagnosis</th><th>Treatment</th><th>Doctor</th></tr>
        <tr><td>15 June 2023</td><td>Chris Hani Baragwanath</td><td>Bronchitis</td>
          <td>Prescribed antibiotics (Amoxicillin 500mg, 7 days) and cough suppressant (Codeine Linctus).</td>
          <td>Dr. Thandi Ndlela</td></tr>
        <tr><td>28 July 2023</td><td>Charlotte Maxeke Johannesburg</td><td>Acute Gastritis</td>
          <td>IV fluids for dehydration, prescribed Proton Pump Inhibitor (Omeprazole 20mg).</td>
          <td>Dr. Johan Dlamini</td></tr>
        <tr><td>10 August 2023</td><td>Helen Joseph Hospital</td><td>Sprained Ankle</td>
          <td>X-ray confirmed no fracture. Ankle brace provided, and physiotherapy sessions recommended.</td>
          <td>Dr. Lerato Khumalo</td></tr>
        <tr><td>22 September 2023</td><td>Steve Biko Academic Hospital</td><td>Hypertension (Stage 1)</td>
          <td>Initiated lifestyle modification program and prescribed Amlodipine 5mg daily.</td>
          <td>Dr. Sipho Ngcobo</td></tr>
        <tr><td>03 November 2023</td><td>Nelson Mandela Children's</td><td>Seasonal Allergies (Rhinitis)</td>
          <td>Prescribed antihistamine (Cetirizine 10mg) and intranasal corticosteroid (Fluticasone spray).</td>
          <td>Dr. Precious Nkosi</td></tr>
      </table>
      <hr>
      <h3>Allergies</h3>
      <p><strong>None reported.</strong></p>
      <h3>Current Medications</h3>
      <ul>
        <li>Amlodipine 5mg daily for Hypertension</li>
        <li>Cetirizine 10mg as needed for seasonal allergies</li>
      </ul>
      <h3>Upcoming Appointments</h3>
      <ul>
        <li>20 November 2023: Follow-up for hypertension at Helen Joseph Hospital with Dr. Sipho Ngcobo.</li>
        <li>05 December 2023: Routine general check-up at Chris Hani Baragwanath with Dr. Thandi Ndlela.</li>
      </ul>
    `
  },
  { 
    name: "Thabo", 
    surname: "Natho", 
    id: "123456789", 
    file: `
      <h2>Medical File: Thabo Natho</h2>
      <p><strong>Full Name:</strong> Thabo Natho</p>
      <p><strong>ID Number:</strong> 123456789</p>
      <p><strong>Date of Birth:</strong> 14 March 1985</p>
      <p><strong>Gender:</strong> Male</p>
      <hr>
      <h3>Medical History (July 2022 - Present)</h3>
      <table>
        <tr><th>Date</th><th>Hospital</th><th>Diagnosis</th><th>Treatment</th><th>Doctor</th></tr>
        <tr><td>12 July 2022</td><td>Charlotte Maxeke Johannesburg</td><td>Diabetes Type 2</td>
          <td>Initiated Metformin 500mg daily, recommended dietary changes.</td>
          <td>Dr. John Mahlangu</td></tr>
        <tr><td>03 April 2023</td><td>Steve Biko Academic Hospital</td><td>Hypertension</td>
          <td>Prescribed Losartan 50mg daily, advised exercise and low-sodium diet.</td>
          <td>Dr. Maria Nkosi</td></tr>
        <tr><td>20 August 2023</td><td>Chris Hani Baragwanath</td><td>Chronic Back Pain</td>
          <td>Physical therapy sessions recommended. Prescribed Ibuprofen 400mg as needed.</td>
          <td>Dr. Sipho Dlamini</td></tr>
      </table>
      <hr>
      <h3>Allergies</h3>
      <p><strong>Penicillin.</strong></p>
      <h3>Current Medications</h3>
      <ul>
        <li>Metformin 500mg daily for Diabetes Type 2</li>
        <li>Losartan 50mg daily for Hypertension</li>
      </ul>
      <h3>Upcoming Appointments</h3>
      <ul>
        <li>25 November 2023: Check-up at Charlotte Maxeke Johannesburg with Dr. John Mahlangu.</li>
      </ul>
    `
  }
];

// Form submission handler
document.getElementById("searchForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const name = document.getElementById("name").value.trim();
  const surname = document.getElementById("surname").value.trim();
  const idNumber = document.getElementById("idNumber").value.trim();

  const result = database.find(
    (entry) => entry.name.toLowerCase() === name.toLowerCase() && 
               entry.surname.toLowerCase() === surname.toLowerCase() &&
               entry.id === idNumber
  );

  document.getElementById("result").innerHTML = result
    ? result.file
    : "<p style='color: red;'>No matching file found.</p>";
});
